
mkdir basalt && Set-Location basalt
# …save the files above…
npm install
npm start
# → http://localhost:3000